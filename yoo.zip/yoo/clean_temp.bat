@echo off
del /q /f %TEMP%\*
for /d %%x in (%TEMP%\*) do rd /s /q "%%x"
pause
