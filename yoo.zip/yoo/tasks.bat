@echo off
tasklist
pause
