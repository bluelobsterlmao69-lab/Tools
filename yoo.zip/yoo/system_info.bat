@echo off
systeminfo
pause
